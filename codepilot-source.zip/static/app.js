const TEXT = {
  bn: {
    loginTitle:"সাইন ইন",loginHint:"অ্যাপ পাসওয়ার্ড দিন।",password:"পাসওয়ার্ড",login:"সাইন ইন",logout:"লগআউট",
    brandSub:"AI code review · workflow",localOnly:"শুধু লোকাল",tabUpload:"আপলোড",tabWorkflow:"ওয়ার্কফ্লো",tabReviewers:"রিভিউ",tabChat:"চ্যাট",tabSettings:"সেটিংস",tabHistory:"ইতিহাস",
    eyebrow:"আপনার ডিভাইসে চলে",heroTitle:"কোড চালান। একাধিক AI দিয়ে রিভিউ করুন।",heroText:"একটি প্রজেক্ট আপলোড করুন; নিরাপদ ধাপগুলো তৈরি, চালানো এবং লাইভ লগ দেখা হবে।",
    projectName:"প্রজেক্টের নাম",projectPlaceholder:"যেমন: আমার Python অ্যাপ",chooseFiles:"ফাইল বা ZIP বেছে নিন",uploadHint:"একাধিক ফাইল · ZIP-slip সুরক্ষা · সর্বোচ্চ 25 MB",uploadBtn:"প্রজেক্ট আপলোড",
    safetyNote:"শুধু বিশ্বাসযোগ্য কোড চালান। প্রোগ্রামটি আপনার Termux/Linux ব্যবহারকারীর অনুমতিতে চলে; এটি OS sandbox নয়।",
    workflowEyebrow:"লাইভ রান",workflowTitle:"ওয়ার্কফ্লো",runBtn:"ওয়ার্কফ্লো চালান",stopBtn:"বন্ধ করুন",workflowEmpty:"প্রথমে একটি প্রজেক্ট আপলোড করুন।",liveLogs:"লাইভ লগ",clear:"মুছুন",
    reviewEyebrow:"দুই দৃষ্টিকোণ",reviewsTitle:"AI রিভিউ",reviewsEmpty:"ওয়ার্কফ্লো শেষ হলে রিভিউ এখানে দেখা যাবে।",chatEyebrow:"কোড সহায়ক",chatTitle:"চ্যাট",chatEmpty:"একটি কোড প্রশ্ন লিখুন।",chatPlaceholder:"কোড বা লগ নিয়ে প্রশ্ন করুন…",send:"পাঠান",
    settingsEyebrow:"মডেল কনফিগারেশন",settingsTitle:"সেটিংস",modelsTitle:"মডেল",addModel:"+ মডেল",modelHint:"API key শুধু .env-এ রাখুন। এখানে key-এর নাম ও কনফিগারেশন থাকে—key value নয়।",
    rolesTitle:"এজেন্টের মডেল",saveSettings:"সেটিংস সংরক্ষণ",historyEyebrow:"আগের কাজ",historyTitle:"ইতিহাস",refresh:"রিফ্রেশ",historyEmpty:"এখনও কোনো রান নেই।"
  },
  en: {
    loginTitle:"Sign in",loginHint:"Enter the app password.",password:"Password",login:"Sign in",logout:"Log out",
    brandSub:"AI code review · workflow",localOnly:"Local only",tabUpload:"Upload",tabWorkflow:"Workflow",tabReviewers:"Reviewers",tabChat:"Chat",tabSettings:"Settings",tabHistory:"History",
    eyebrow:"Runs on your device",heroTitle:"Run code. Review it with multiple AIs.",heroText:"Upload a project to plan safe workflow steps, run them, and watch live logs.",
    projectName:"Project name",projectPlaceholder:"For example: my Python app",chooseFiles:"Choose files or a ZIP",uploadHint:"Multiple files · ZIP-slip protection · 25 MB maximum",uploadBtn:"Upload project",
    safetyNote:"Run trusted code only. Programs run with your Termux/Linux user permissions; this is not an OS sandbox.",
    workflowEyebrow:"Live run",workflowTitle:"Workflow",runBtn:"Run workflow",stopBtn:"Stop",workflowEmpty:"Upload a project first.",liveLogs:"Live logs",clear:"Clear",
    reviewEyebrow:"Two perspectives",reviewsTitle:"AI reviews",reviewsEmpty:"Reviews appear here when the workflow finishes.",chatEyebrow:"Code assistant",chatTitle:"Chat",chatEmpty:"Ask a coding question.",chatPlaceholder:"Ask about code or logs…",send:"Send",
    settingsEyebrow:"Model configuration",settingsTitle:"Settings",modelsTitle:"Models",addModel:"+ Add model",modelHint:"Keep API keys only in .env. This page stores the key's environment-variable name, never its value.",
    rolesTitle:"Agent assignments",saveSettings:"Save settings",historyEyebrow:"Previous work",historyTitle:"History",refresh:"Refresh",historyEmpty:"No runs yet."
  }
};

const $ = (selector, parent=document) => parent.querySelector(selector);
const $$ = (selector, parent=document) => [...parent.querySelectorAll(selector)];
let language = localStorage.getItem("codepilot-language") || "bn";
let currentProject = null;
let currentRun = null;
let eventSource = null;
let modelConfig = {models:[],assignments:{}};
const reviewsByAgent = {};

function translate() {
  document.documentElement.lang = language;
  for (const el of $$("[data-i18n]")) el.textContent = TEXT[language][el.dataset.i18n] || el.textContent;
  for (const el of $$("[data-i18n-placeholder]")) el.placeholder = TEXT[language][el.dataset.i18nPlaceholder] || el.placeholder;
  $("#lang-toggle").textContent = language === "bn" ? "EN" : "বাংলা";
}
function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
}
async function api(path, options={}) {
  const response = await fetch(path, {credentials:"same-origin", ...options});
  let data = {};
  try { data = await response.json(); } catch {}
  if (response.status === 401 && path !== "/api/login") {
    showLogin();
    throw new Error(data.detail || "Login required");
  }
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
}
function showLogin() {
  $("#login-screen").classList.remove("hidden");
  $("#app-shell").classList.add("hidden");
  $("#password").focus();
}
function showApp(session) {
  $("#login-screen").classList.add("hidden");
  $("#app-shell").classList.remove("hidden");
  $("#logout-btn").classList.toggle("hidden", !session.auth_enabled);
  $("#security-warning").textContent = session.warning || "";
  $("#security-warning").classList.toggle("hidden", !session.warning);
  $("#public-url").textContent = session.tunnel_url || "";
  $("#public-url").href = session.tunnel_url || "#";
  $("#public-url").classList.toggle("hidden", !session.tunnel_url);
  $("#local-badge").classList.toggle("hidden", Boolean(session.tunnel_url));
  if (!session.tunnel_url) {
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts++;
      try {
        const latest = await api("/api/session");
        if (latest.tunnel_url || attempts >= 30) {
          clearInterval(poll);
          if (latest.tunnel_url) showApp(latest);
        }
      } catch { clearInterval(poll); }
    }, 2000);
  }
}
function element(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}
function addCopyButton(parent, value) {
  const button = element("button","ghost small-btn",language==="bn"?"কপি":"Copy");
  button.type = "button";
  button.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(value); toast(language==="bn"?"কপি হয়েছে":"Copied"); }
    catch { toast(language==="bn"?"কপি করা যায়নি":"Could not copy"); }
  });
  parent.append(button);
}
function renderTagged(parent, text) {
  const source = String(text || "");
  const pattern = /<(note|code)\b([^>]*)>([\s\S]*?)<\/\1\s*>/gi;
  let cursor = 0, match, found = false;
  while ((match = pattern.exec(source))) {
    found = true;
    if (match.index > cursor) parent.append(element("p","plain-copy",source.slice(cursor,match.index).trim()));
    const kind = match[1].toLowerCase();
    const content = match[3].replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");
    const card = element("div",`tag-card ${kind}`);
    const head = element("div","tag-heading");
    const langMatch = /\blang\s*=\s*["']([^"']+)["']/i.exec(match[2]);
    const fileMatch = /\bfile\s*=\s*["']([^"']+)["']/i.exec(match[2]);
    const label = kind === "note" ? (language==="bn"?"বিশেষ নোট":"Special note") : `${langMatch?.[1] || "code"}${fileMatch?.[1] ? " · "+fileMatch[1] : ""}`;
    head.append(element("span","tag-kind",label));
    addCopyButton(head,content.trim());
    card.append(head,kind==="code"?element("pre","code-content",content.trim()):element("div","plain-copy",content.trim()));
    parent.append(card);
    cursor = pattern.lastIndex;
  }
  if (cursor < source.length) parent.append(element("p","plain-copy",source.slice(cursor).trim()));
  if (!found && !source.trim()) parent.append(element("p","muted tiny",language==="bn"?"কোনো রিভিউ নেই।":"No review text."));
}
function renderOutputCards(parent, outputs) {
  for (const output of outputs || []) {
    const card = element("article","output-card");
    card.append(element("h4","",output.filename));
    card.append(element("div","output-meta",`${output.language || "text"} · ${output.size} bytes · ${output.line_count} lines`));
    card.append(element("pre","output-preview",output.preview || ""));
    const actions = element("div","output-actions");
    const download = element("a","primary small-btn",language==="bn"?"ডাউনলোড":"Download");
    download.href = output.download_url;
    download.download = output.filename;
    const copy = element("button","ghost small-btn",language==="bn"?"কোড কপি":"Copy code");
    copy.type = "button";
    copy.addEventListener("click", async () => {
      try {
        const response = await fetch(output.download_url,{credentials:"same-origin"});
        if (!response.ok) throw new Error();
        await navigator.clipboard.writeText(await response.text());
        toast(language==="bn"?"কোড কপি হয়েছে":"Code copied");
      } catch { toast(language==="bn"?"ফাইল পড়া যায়নি":"Could not read file"); }
    });
    actions.append(download,copy);
    card.append(actions);
    parent.append(card);
  }
}
function activateTab(name) {
  $$(".tab").forEach(tab => tab.classList.toggle("active",tab.dataset.tab===name));
  $$(".panel").forEach(panel => panel.classList.toggle("active",panel.id===`panel-${name}`));
  if (name==="history") refreshHistory();
  if (name==="settings") loadSettings();
}
$$(".tab").forEach(tab => tab.addEventListener("click",()=>activateTab(tab.dataset.tab)));
$("#lang-toggle").addEventListener("click",()=>{
  language = language==="bn"?"en":"bn";
  localStorage.setItem("codepilot-language",language);
  translate();
});
$("#login-form").addEventListener("submit",async event=>{
  event.preventDefault();
  $("#login-error").textContent="";
  try {
    await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("#password").value})});
    $("#password").value="";
    await startApp();
  } catch(error) { $("#login-error").textContent=error.message; }
});
$("#logout-btn").addEventListener("click",async()=>{
  try { await api("/api/logout",{method:"POST"}); showLogin(); } catch(error) { toast(error.message); }
});
$("#files-input").addEventListener("change",()=>{
  const list = [...$("#files-input").files].map(file=>`${file.name} (${Math.ceil(file.size/1024)} KB)`);
  $("#selected-files").textContent=list.join(" · ");
});
$("#upload-form").addEventListener("submit",async event=>{
  event.preventDefault();
  const button = event.submitter;
  button.disabled=true;
  const form = new FormData();
  form.append("name",$("#project-name").value);
  for(const file of $("#files-input").files) form.append("files",file,file.name);
  try {
    currentProject=await api("/api/projects",{method:"POST",body:form});
    localStorage.setItem("codepilot-project",currentProject.id);
    showCurrentProject();
    $("#upload-form").reset(); $("#selected-files").textContent="";
    toast(language==="bn"?"প্রজেক্ট আপলোড হয়েছে":"Project uploaded");
    activateTab("workflow");
  } catch(error) { toast(error.message); }
  finally { button.disabled=false; }
});
function showCurrentProject() {
  const card=$("#current-project");
  card.classList.toggle("hidden",!currentProject);
  $("#run-btn").disabled=!currentProject || Boolean(currentRun);
  $("#workflow-empty").classList.toggle("hidden",Boolean(currentProject));
  if (!currentProject) return;
  card.replaceChildren();
  const title=element("h3","",currentProject.name);
  const detail=element("p","muted tiny",`${currentProject.language || "Unknown"} · ${currentProject.file_count || "—"} ${language==="bn"?"টি ফাইল":"files"}`);
  const switchBtn=element("button","ghost small-btn",language==="bn"?"ইতিহাসে দেখুন":"View history");
  switchBtn.type="button"; switchBtn.addEventListener("click",()=>activateTab("history"));
  card.append(title,detail,switchBtn);
}
$("#run-btn").addEventListener("click",startRun);
$("#stop-btn").addEventListener("click",async()=>{
  if (!currentRun) return;
  try { await api(`/api/runs/${currentRun}/stop`,{method:"POST"}); toast(language==="bn"?"বন্ধ করার অনুরোধ পাঠানো হয়েছে":"Stop requested"); }
  catch(error){toast(error.message);}
});
$("#clear-logs").addEventListener("click",()=>{$("#live-logs").textContent="";$("#steps-list").replaceChildren();});
async function startRun() {
  if(!currentProject || currentRun) return;
  $("#run-btn").disabled=true; $("#stop-btn").classList.remove("hidden");
  $("#steps-list").replaceChildren(); $("#live-logs").textContent="";
  $("#reviews-grid").replaceChildren(); $("#output-files").replaceChildren(); $("#review-summary").classList.add("hidden");
  Object.keys(reviewsByAgent).forEach(key=>delete reviewsByAgent[key]);
  try {
    const result=await api(`/api/projects/${currentProject.id}/run`,{method:"POST"});
    currentRun=result.run_id;
    eventSource=new EventSource(`/api/runs/${currentRun}/events`);
    eventSource.onmessage=message=>{
      let data;
      try { data=JSON.parse(message.data); } catch { return; }
      handleRunEvent(data);
    };
    eventSource.onerror=()=>{ if(currentRun) toast(language==="bn"?"লাইভ সংযোগ বিচ্ছিন্ন হয়েছে":"Live stream disconnected"); };
    activateTab("workflow");
  } catch(error) {
    toast(error.message); currentRun=null; $("#run-btn").disabled=false; $("#stop-btn").classList.add("hidden");
  }
}
function handleRunEvent(data) {
  if(data.event==="plan") {
    $("#workflow-empty").classList.add("hidden");
    for(const [index,step] of data.steps.entries()) addStep(`step-${index+1}`,step.label,"pending");
    return;
  }
  if(data.event==="step"){updateStep(data.id,data.label,data.status);return;}
  if(data.event==="log") {
    const logs=$("#live-logs"); logs.textContent+=data.text||""; logs.scrollTop=logs.scrollHeight; return;
  }
  if(data.event==="review_status"){toast(data.status==="running"?(language==="bn"?"রিভিউ চলছে…":"Reviews running…"):(language==="bn"?"রিভিউ সম্পন্ন":"Reviews complete"));return;}
  if(data.event==="review") {
    reviewsByAgent[data.agent]=data;
    renderReviews();
    renderOutputCards($("#output-files"),data.outputs||[]);
    return;
  }
  if(data.event==="error"){toast(data.message||"Workflow error");return;}
  if(data.event==="stopped"){toast(language==="bn"?"রান বন্ধ হয়েছে":"Run stopped");return;}
  if(data.event==="done"){
    currentRun=null; eventSource?.close(); eventSource=null;
    $("#stop-btn").classList.add("hidden"); $("#run-btn").disabled=!currentProject;
    refreshHistory();
  }
}
function addStep(id,label,status) {
  let item=$(`[data-step="${id}"]`);
  if(!item){item=element("div","step-item");item.dataset.step=id;item.append(element("span","step-dot"),element("span","step-name"),element("span","step-status"));$("#steps-list").append(item);}
  item.className=`step-item ${status}`; $(".step-name",item).textContent=label; $(".step-status",item).textContent=status;
}
function updateStep(id,label,status){addStep(id,label,status);}
function renderReviews() {
  const grid=$("#reviews-grid"); grid.replaceChildren();
  const list=Object.values(reviewsByAgent);
  for(const review of list){
    const card=element("article","review-card");
    card.append(element("h3","",review.label));
    if(review.model) card.append(element("div","review-meta",`${language==="bn"?"মডেল":"Model"}: ${review.model}`));
    const body=element("div",""); renderTagged(body,review.text); card.append(body); grid.append(card);
  }
  if(list.length===2){
    const summary=$("#review-summary"); summary.classList.remove("hidden"); summary.replaceChildren();
    summary.append(element("h3","",language==="bn"?"সমন্বিত সারাংশ":"Combined summary"));
    const text=list.map(item=>`${item.label}: ${(item.text||"").replace(/<[^>]+>/g," ").trim().slice(0,350)}`).join("\n\n");
    summary.append(element("p","response-text",text));
  }
}
$("#chat-form").addEventListener("submit",async event=>{
  event.preventDefault();
  const input=$("#chat-input"), message=input.value.trim(); if(!message)return;
  $("#chat-messages").querySelector(".empty-state")?.remove();
  $("#chat-messages").append(element("div","message-card user",message));
  input.value=""; $("#chat-send").disabled=true;
  const answer=element("article","message-card assistant");
  answer.append(element("div","message-label","Assistant"));
  const body=element("div",""); body.textContent=language==="bn"?"ভাবছি…":"Thinking…"; answer.append(body);
  $("#chat-messages").append(answer); answer.scrollIntoView({block:"nearest"});
  try{
    const result=await api("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,project_id:currentProject?.id||""})});
    body.replaceChildren();renderTagged(body,result.text);renderOutputCards($("#chat-outputs"),result.outputs);
  }catch(error){body.textContent=error.message;}
  finally{$("#chat-send").disabled=false;}
});

function field(labelText,value,type="text",placeholder="") {
  const wrap=element("div","model-field");
  wrap.append(element("label","",labelText));
  const input=document.createElement("input");input.type=type;input.value=value||"";input.placeholder=placeholder;
  wrap.append(input);return {wrap,input};
}
function renderModels() {
  const list=$("#models-list");list.replaceChildren();
  modelConfig.models.forEach((model,index)=>{
    const row=element("div","model-row");row.dataset.index=index;
    const top=element("div","model-top");
    const enabled=document.createElement("input");enabled.type="checkbox";enabled.checked=Boolean(model.enabled);enabled.className="model-enabled";
    const status=element("span","muted tiny",model.key_configured?(language==="bn"?"API key সেট":"API key set"):(language==="bn"?"API key নেই":"API key missing"));
    const toggle=element("label","model-toggle");toggle.append(enabled,status);
    const remove=element("button","danger small-btn",language==="bn"?"মুছুন":"Remove");remove.type="button";remove.addEventListener("click",()=>{modelConfig.models.splice(index,1);renderModels();renderRoles();});
    top.append(toggle,remove);row.append(top);
    const controls=[
      ["Name",model.name,"name"],["Provider",model.provider,"provider"],
      ["Base URL",model.base_url,"base_url"],["Model ID",model.model_id,"model_id"],
      ["Key environment variable",model.api_key_env,"api_key_env"]
    ];
    for(const [label,value,key] of controls){
      const {wrap,input}=field(label,value);
      input.dataset.key=key;input.classList.add("model-value");
      if(key==="provider"){
        const select=document.createElement("select");
        ["openai-compatible","anthropic","gemini"].forEach(option=>{const item=document.createElement("option");item.value=option;item.textContent=option;select.append(item);});
        select.value=value;select.dataset.key=key;select.className="model-value";wrap.replaceChild(select,input);
      }
      row.append(wrap);
    }
    list.append(row);
  });
}
function renderRoles() {
  const list=$("#roles-list");list.replaceChildren();
  const labels={backend_reviewer:language==="bn"?"Backend Reviewer":"Backend Reviewer",syntax_reviewer:language==="bn"?"Syntax Reviewer":"Syntax Reviewer",workflow_runner:language==="bn"?"Workflow Runner":"Workflow Runner"};
  for(const role of ["backend_reviewer","syntax_reviewer","workflow_runner"]){
    const row=element("label","role-row",labels[role]);
    const select=document.createElement("select");select.dataset.role=role;
    const empty=document.createElement("option");empty.value="";empty.textContent=language==="bn"?"মডেল বাছুন":"Select model";select.append(empty);
    for(const model of modelConfig.models){const option=document.createElement("option");option.value=model.name;option.textContent=model.name;select.append(option);}
    select.value=modelConfig.assignments?.[role]||"";row.append(select);list.append(row);
  }
}
async function loadSettings() {
  try{modelConfig=await api("/api/settings");renderModels();renderRoles();}
  catch(error){toast(error.message);}
}
$("#add-model").addEventListener("click",()=>{
  modelConfig.models.push({name:"New model",provider:"openai-compatible",base_url:"https://api.example.com/v1",model_id:"model-id",api_key_env:"MODEL_API_KEY",enabled:false,key_configured:false});
  renderModels();renderRoles();
});
$("#save-settings").addEventListener("click",async()=>{
  const models=$$(".model-row").map(row=>{
    const model={};
    $$(".model-value",row).forEach(input=>model[input.dataset.key]=input.value.trim());
    model.enabled=$(".model-enabled",row).checked;
    return model;
  });
  const assignments={};$$("[data-role]").forEach(select=>assignments[select.dataset.role]=select.value);
  $("#save-settings").disabled=true;
  try{modelConfig=await api("/api/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({models,assignments})});renderModels();renderRoles();$("#settings-status").textContent=language==="bn"?"সংরক্ষিত":"Saved";}
  catch(error){$("#settings-status").textContent=error.message;}
  finally{$("#save-settings").disabled=false;}
});

async function refreshHistory() {
  const container=$("#history-list");
  try{
    const [history,projects]=await Promise.all([api("/api/history"),api("/api/projects")]);
    container.replaceChildren();
    const projectItems=(projects.projects||[]).map(project=>({...project,type:"project"}));
    const runs=(history.runs||[]).map(run=>({...run,type:"run"}));
    if(!projectItems.length&&!runs.length){container.append(element("div","empty-state",TEXT[language].historyEmpty));return;}
    if(projectItems.length)container.append(element("p","eyebrow",language==="bn"?"প্রজেক্ট":"Projects"));
    for(const project of projectItems){
      const item=element("div","history-item"),info=element("div","");
      info.append(element("div","history-title",project.name));
      info.append(element("div","history-meta",`${project.language} · ${project.created_at}`));
      const button=element("button","secondary small-btn",language==="bn"?"খুলুন":"Open");button.type="button";
      button.addEventListener("click",()=>selectProject(project));
      item.append(info,button);container.append(item);
    }
    if(runs.length)container.append(element("p","eyebrow",language==="bn"?"রান":"Runs"));
    for(const run of runs){
      const item=element("div","history-item"),info=element("div","");
      info.append(element("div","history-title",`${run.project_name} · ${run.status}`));
      info.append(element("div","history-meta",run.created_at));
      const button=element("button","ghost small-btn",language==="bn"?"প্রজেক্ট":"Project");button.type="button";
      button.addEventListener("click",async()=>{try{const project=await api(`/api/projects/${run.project_id}`);await selectProject(project.project);}catch(error){toast(error.message);}});
      item.append(info,button);container.append(item);
    }
  }catch(error){container.replaceChildren(element("div","empty-state",error.message));}
}
async function selectProject(project) {
  currentProject=project;localStorage.setItem("codepilot-project",project.id);showCurrentProject();
  try{
    const data=await api(`/api/projects/${project.id}`);
    currentProject={...data.project};
    showCurrentProject();
    $("#reviews-grid").replaceChildren();
    Object.keys(reviewsByAgent).forEach(key=>delete reviewsByAgent[key]);
    for(const review of [...(data.reviews||[])].reverse()){
      const labels={backend_reviewer:"Backend Reviewer",syntax_reviewer:"Syntax Reviewer"};
      reviewsByAgent[review.agent]={agent:review.agent,label:labels[review.agent]||review.agent,text:review.text,model:review.model_name};
    }
    renderReviews();
    toast(language==="bn"?"প্রজেক্ট খোলা হয়েছে":"Project opened");
    activateTab("workflow");
  }catch(error){toast(error.message);}
}
$("#refresh-history").addEventListener("click",refreshHistory);

async function startApp() {
  try {
    const session=await api("/api/session");
    if(session.auth_enabled&&!session.authenticated){showLogin();return;}
    showApp(session);
    await loadSettings();
    const saved=localStorage.getItem("codepilot-project");
    if(saved){
      try{const data=await api(`/api/projects/${saved}`);currentProject=data.project;showCurrentProject();$("#reviews-grid").replaceChildren();Object.keys(reviewsByAgent).forEach(key=>delete reviewsByAgent[key]);for(const review of [...data.reviews].reverse())reviewsByAgent[review.agent]={agent:review.agent,label:review.agent==="backend_reviewer"?"Backend Reviewer":"Syntax Reviewer",text:review.text,model:review.model_name};renderReviews();}
      catch{localStorage.removeItem("codepilot-project");}
    }
  } catch(error) { toast(error.message); }
}
translate();
startApp();
